const incom = document.querySelector(".income");
const food = document.querySelector(".food");
const rent = document.querySelector(".rent");
const clothes = document.querySelector(".clothes");
let totalExpences;

// calclute.addEventListener("click", calc);

function totalExpencesFun() {
  const totalExpences =
    parseInt(food.value) + parseInt(rent.value) + parseInt(clothes.value);
  return totalExpences;
}

function newBalanceFunction() {
  const income = parseInt(incom.value);
  return (newBalance = income - totalExpencesFun());
}

function exCalclute() {
  // const income = parseInt(incom.value);
  // const totalExpences =
  //   parseInt(food.value) + parseInt(rent.value) + parseInt(clothes.value);

  // const newBalance = income - totalExpences;

  document.querySelector(".expencess").innerHTML = totalExpencesFun();
  document.querySelector(".balance").innerHTML = newBalanceFunction();
  // return totalExpences;
  // console.log(totalExpences);
  console.log(totalExpencesFun());
}

function saveingsCalclute() {
  console.log(exCalclute.totalExpencesFun());
}
